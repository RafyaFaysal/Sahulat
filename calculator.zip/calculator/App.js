import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView, 
  SafeAreaView,
  FlatList
} from 'react-native';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';

const SahulatCalculator = () => {
  // Calculator state
  const [currentInput, setCurrentInput] = useState('0');
  const [previousInput, setPreviousInput] = useState(null);
  const [operation, setOperation] = useState(null);
  const [decimalAdded, setDecimalAdded] = useState(false);
  const [notification, setNotification] = useState('');
  const [connected, setConnected] = useState(false);
  const [connectionType, setConnectionType] = useState(null);
  const [transactionMode, setTransactionMode] = useState(false);
  const [transactionType, setTransactionType] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [description, setDescription] = useState('');
  const [transactionStep, setTransactionStep] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: 'calculator', title: 'Calculator' },
    { key: 'transactions', title: 'Transaction Log' },
  ]);

  // Categories for different transaction types
  const categories = {
    'sales': ['Daily Sales', 'Bulk Order', 'Service Fee', 'Other Sales'],
    'expenses': ['Inventory', 'Rent', 'Utilities', 'Salaries', 'Other Expenses'],
    'udhaar': ['Customer Credit', 'Supplier Payment', 'Loan', 'Other Credit']
  };

  // Clear notification after timeout
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const showNotification = (message) => {
    setNotification(message);
  };

  const onNumberClick = (number) => {
    if (transactionMode && transactionStep === 0) {
      // In category selection mode, numbers select categories
      if (number >= 1 && number <= categories[transactionType].length) {
        setSelectedCategory(categories[transactionType][number - 1]);
        setTransactionStep(1);
      }
      return;
    }

    if (currentInput === '0') {
      setCurrentInput(number.toString());
    } else {
      setCurrentInput(currentInput + number.toString());
    }
  };

  const onDoubleZeroClick = () => {
    if (currentInput === '0') return;
    setCurrentInput(currentInput + '00');
  };

  const onDecimalClick = () => {
    if (!decimalAdded) {
      setCurrentInput(currentInput + '.');
      setDecimalAdded(true);
    }
  };

  const onOperationClick = (op) => {
    if (transactionMode) return;

    if (previousInput !== null && operation) {
      onEqualsClick();
    }

    setPreviousInput(currentInput);
    setOperation(op);
    setCurrentInput('0');
    setDecimalAdded(false);
  };

  const onEqualsClick = () => {
    if (transactionMode) {
      if (transactionStep === 1) {
        // Save the transaction
        saveTransaction();
      }
      return;
    }

    if (previousInput !== null && operation) {
      try {
        // Using Function constructor instead of eval for better security
        const calculate = new Function('a', 'b', `return a ${operation} b`);
        const result = calculate(parseFloat(previousInput), parseFloat(currentInput));
        
        const resultStr = result.toString();
        setCurrentInput(resultStr.endsWith('.0') ? resultStr.slice(0, -2) : resultStr);
        setPreviousInput(null);
        setOperation(null);
        setDecimalAdded(resultStr.includes('.'));
      } catch (e) {
        setCurrentInput('Error');
        setPreviousInput(null);
        setOperation(null);
        setDecimalAdded(false);
      }
    }
  };

  const onClearClick = () => {
    if (transactionMode) {
      cancelTransaction();
      return;
    }
    
    setCurrentInput('0');
    setDecimalAdded(false);
  };

  const onAllClearClick = () => {
    setCurrentInput('0');
    setPreviousInput(null);
    setOperation(null);
    setDecimalAdded(false);
  };

  const onPercentClick = () => {
    if (transactionMode) return;
    
    try {
      const value = parseFloat(currentInput) / 100;
      const valueStr = value.toString();
      setCurrentInput(valueStr.endsWith('.0') ? valueStr.slice(0, -2) : valueStr);
      setDecimalAdded(valueStr.includes('.'));
    } catch {
      setCurrentInput('Error');
      setDecimalAdded(false);
    }
  };

  const onArrowClick = () => {
    if (currentInput.length > 1) {
      const newInput = currentInput.slice(0, -1);
      setCurrentInput(newInput);
      setDecimalAdded(newInput.includes('.'));
    } else {
      setCurrentInput('0');
      setDecimalAdded(false);
    }
  };

  const onSyncClick = () => {
    if (!connected) {
      showNotification('Please connect first');
      return;
    }
    
    showNotification('Syncing data...');
    // Simulate syncing delay
    setTimeout(() => {
      showNotification('Data synced successfully!');
    }, 1500);
  };

  const onTransactionClick = (type) => {
    if (parseFloat(currentInput) <= 0) {
      showNotification('Please enter a valid amount');
      return;
    }
    
    setTransactionMode(true);
    setTransactionType(type);
    setTransactionStep(0);
    setSelectedCategory(null);
    setDescription('');
  };

  const onConnectionClick = (type) => {
    if (connected && connectionType === type) {
      setConnected(false);
      setConnectionType(null);
      showNotification(`${type} disconnected`);
    } else {
      setConnected(true);
      setConnectionType(type);
      showNotification(`Connected via ${type}`);
    }
  };

  const saveTransaction = () => {
    try {
      const amount = parseFloat(currentInput);
      const newTransaction = {
        id: Date.now().toString(),
        timestamp: new Date(),
        amount: amount,
        category: selectedCategory,
        type: transactionType,
        description: description
      };
      
      setTransactions([newTransaction, ...transactions]);
      showNotification(`${transactionType.charAt(0).toUpperCase() + transactionType.slice(1)} of ${amount} recorded!`);
      cancelTransaction();
      
    } catch (e) {
      showNotification(`Error: ${e.message}`);
      cancelTransaction();
    }
  };

  const cancelTransaction = () => {
    setTransactionMode(false);
    setTransactionStep(0);
    setSelectedCategory(null);
    setDescription('');
  };

  // Calculator Display Component
  const CalculatorDisplay = () => {
    if (!transactionMode) {
      return (
        <View style={styles.display}>
          <Text style={styles.displayText}>{currentInput}</Text>
          <View style={styles.displayFooter}>
            <Text style={styles.displayFooterText}>
              {connected ? `Connected via ${connectionType}` : 'Not connected'}
            </Text>
            <Text style={styles.displayFooterText}>Sahulat App</Text>
          </View>
          {notification ? (
            <Text style={styles.notification}>{notification}</Text>
          ) : null}
        </View>
      );
    } else if (transactionStep === 0) {
      return (
        <View style={styles.display}>
          <Text style={styles.transactionTitle}>
            Record {transactionType.charAt(0).toUpperCase() + transactionType.slice(1)}: {currentInput}
          </Text>
          <Text style={styles.transactionSubtitle}>Select category (press number):</Text>
          <View style={styles.categoryContainer}>
            {categories[transactionType].map((category, index) => (
              <TouchableOpacity
                key={index}
                style={styles.categoryButton}
                onPress={() => onNumberClick(index + 1)}
              >
                <Text style={styles.categoryButtonText}>{index + 1}. {category}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.transactionFooter}>Press C to cancel</Text>
        </View>
      );
    } else {
      return (
        <View style={styles.display}>
          <Text style={styles.transactionTitle}>
            {transactionType.charAt(0).toUpperCase() + transactionType.slice(1)}: {currentInput}
          </Text>
          <Text style={styles.transactionSubtitle}>
            Category: {selectedCategory}
          </Text>
          <Text style={styles.transactionDescription}>
            Add description (optional): {description}
          </Text>
          <View style={styles.transactionFooterRow}>
            <Text style={styles.transactionFooter}>Press = to save</Text>
            <Text style={styles.transactionFooter}>Press C to cancel</Text>
          </View>
        </View>
      );
    }
  };

  // Calculator Scene
  const CalculatorScene = () => (
    <View style={styles.calculatorContainer}>
      <CalculatorDisplay />
      
      <View style={styles.connectionRow}>
        <TouchableOpacity 
          style={[styles.connectionButton, connectionType === 'WiFi' && connected ? styles.activeConnection : {}]} 
          onPress={() => onConnectionClick('WiFi')}
        >
          <Text style={styles.connectionButtonText}>WiFi</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.connectionButton, connectionType === 'Bluetooth' && connected ? styles.activeConnection : {}]} 
          onPress={() => onConnectionClick('Bluetooth')}
        >
          <Text style={styles.connectionButtonText}>BT</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.buttonGrid}>
        <TouchableOpacity style={[styles.button, styles.functionButton]} onPress={onAllClearClick}>
          <Text style={styles.functionButtonText}>AC</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.functionButton]} onPress={onClearClick}>
          <Text style={styles.functionButtonText}>C</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.functionButton]} onPress={onArrowClick}>
          <Text style={styles.functionButtonText}>←</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.operationButton]} onPress={() => onPercentClick()}>
          <Text style={styles.operationButtonText}>%</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(7)}>
          <Text style={styles.buttonText}>7</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(8)}>
          <Text style={styles.buttonText}>8</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(9)}>
          <Text style={styles.buttonText}>9</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.operationButton]} onPress={() => onOperationClick('+')}>
          <Text style={styles.operationButtonText}>+</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(4)}>
          <Text style={styles.buttonText}>4</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(5)}>
          <Text style={styles.buttonText}>5</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(6)}>
          <Text style={styles.buttonText}>6</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.operationButton]} onPress={() => onOperationClick('-')}>
          <Text style={styles.operationButtonText}>-</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(1)}>
          <Text style={styles.buttonText}>1</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(2)}>
          <Text style={styles.buttonText}>2</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(3)}>
          <Text style={styles.buttonText}>3</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.operationButton]} onPress={() => onOperationClick('*')}>
          <Text style={styles.operationButtonText}>×</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => onNumberClick(0)}>
          <Text style={styles.buttonText}>0</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={onDoubleZeroClick}>
          <Text style={styles.buttonText}>00</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={onDecimalClick}>
          <Text style={styles.buttonText}>.</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.operationButton]} onPress={() => onOperationClick('/')}>
          <Text style={styles.operationButtonText}>÷</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.button, styles.syncButton]} onPress={onSyncClick}>
          <Text style={styles.syncButtonText}>↻</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.equalsButton]} onPress={onEqualsClick}>
          <Text style={styles.equalsButtonText}>=</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.transactionRow}>
        <TouchableOpacity 
          style={[styles.transactionButton, styles.salesButton]} 
          onPress={() => onTransactionClick('sales')}
        >
          <Text style={styles.transactionButtonText}>Sales</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.transactionButton, styles.expenseButton]} 
          onPress={() => onTransactionClick('expenses')}
        >
          <Text style={styles.transactionButtonText}>Expense</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.transactionButton, styles.udhaarButton]} 
          onPress={() => onTransactionClick('udhaar')}
        >
          <Text style={styles.transactionButtonText}>Udhaar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // Transaction Log Scene
  const TransactionLogScene = () => {
    // Calculate summary statistics
    const salesTotal = transactions
      .filter(t => t.type === 'sales')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const expensesTotal = transactions
      .filter(t => t.type === 'expenses')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const udhaarTotal = transactions
      .filter(t => t.type === 'udhaar')
      .reduce((sum, t) => sum + t.amount, 0);
      
    const balance = salesTotal - expensesTotal;

    const renderItem = ({ item }) => {
      const timestamp = new Date(item.timestamp).toLocaleString();
      const typeStyle = item.type === 'sales' ? styles.salesText : 
                        item.type === 'expenses' ? styles.expensesText : 
                        styles.udhaarText;
      
      return (
        <View style={styles.transactionItem}>
          <Text style={styles.transactionDate}>{timestamp}</Text>
          <Text style={[styles.transactionType, typeStyle]}>
            {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
          </Text>
          <Text style={styles.transactionCategory}>{item.category}</Text>
          <Text style={[styles.transactionAmount, typeStyle]}>{item.amount.toFixed(2)}</Text>
          <Text style={styles.transactionDescription}>{item.description}</Text>
        </View>
      );
    };

    return (
      <View style={styles.transactionLogContainer}>
        {transactions.length === 0 ? (
          <Text style={styles.noTransactionsText}>No transactions recorded yet.</Text>
        ) : (
          <>
            <View style={styles.transactionHeader}>
              <Text style={styles.transactionHeaderText}>Date/Time</Text>
              <Text style={styles.transactionHeaderText}>Type</Text>
              <Text style={styles.transactionHeaderText}>Category</Text>
              <Text style={styles.transactionHeaderText}>Amount</Text>
              <Text style={styles.transactionHeaderText}>Description</Text>
            </View>
            <FlatList
              data={transactions}
              renderItem={renderItem}
              keyExtractor={item => item.id}
              style={styles.transactionList}
            />
          </>
        )}
        
        <View style={styles.summaryContainer}>
          <Text style={styles.summaryTitle}>Summary</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Total Sales:</Text>
            <Text style={styles.salesText}>{salesTotal.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Total Expenses:</Text>
            <Text style={styles.expensesText}>{expensesTotal.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Total Udhaar:</Text>
            <Text style={styles.udhaarText}>{udhaarTotal.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Balance:</Text>
            <Text style={balance >= 0 ? styles.salesText : styles.expensesText}>
              {balance.toFixed(2)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  const renderScene = SceneMap({
    calculator: CalculatorScene,
    transactions: TransactionLogScene,
  });

  const renderTabBar = props => (
    <TabBar
      {...props}
      indicatorStyle={styles.tabIndicator}
      style={styles.tabBar}
      labelStyle={styles.tabLabel}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <TabView
        navigationState={{ index, routes }}
        renderScene={renderScene}
        onIndexChange={setIndex}
        renderTabBar={renderTabBar}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  calculatorContainer: {
    padding: 15,
    alignItems: 'center',
  },
  display: {
    backgroundColor: '#E8F5E9',
    padding: 10,
    borderRadius: 8,
    width: '100%',
    height: 120,
    borderWidth: 1,
    borderColor: '#BDBDBD',
    marginBottom: 10,
  },
  displayText: {
    fontSize: 32,
    textAlign: 'right',
    color: '#212121',
    marginBottom: 5,
  },
  displayFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  displayFooterText: {
    fontSize: 12,
    color: '#757575',
  },
  notification: {
    color: '#4CAF50',
    fontSize: 12,
    marginTop: 5,
  },
  connectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 10,
  },
  connectionButton: {
    backgroundColor: '#9C27B0',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
    width: '48%',
    alignItems: 'center',
  },
  activeConnection: {
    backgroundColor: '#4CAF50',
  },
  connectionButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    width: '100%',
  },
  button: {
    backgroundColor: '#FFFFFF',
    width: '22%',
    height: 45,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 8,
    elevation: 2,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
  },
  functionButton: {
    backgroundColor: '#FF9800',
  },
  functionButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  operationButton: {
    backgroundColor: '#FFD54F',
  },
  operationButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
  },
  equalsButton: {
    backgroundColor: '#4CAF50',
    width: '48%',
  },
  equalsButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  syncButton: {
    backgroundColor: '#2196F3',
    width: '48%',
  },
  syncButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  transactionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 10,
  },
  transactionButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    width: '32%',
    alignItems: 'center',
  },
  salesButton: {
    backgroundColor: '#4CAF50',
  },
  expenseButton: {
    backgroundColor: '#F44336',
  },
  udhaarButton: {
    backgroundColor: '#2196F3',
  },
  transactionButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  transactionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
  },
  transactionSubtitle: {
    fontSize: 12,
    color: '#757575',
    marginTop: 5,
  },
  transactionDescription: {
    fontSize: 12,
    color: '#212121',
    marginTop: 5,
  },
  transactionFooter: {
    fontSize: 10,
    color: '#757575',
  },
  transactionFooterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5,
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 3,
  },
  categoryButton: {
    backgroundColor: '#2196F3',
    borderRadius: 4,
    padding: 4,
    margin: 2,
  },
  categoryButtonText: {
    color: 'white',
    fontSize: 10,
  },
  
  // Transaction Log Styles
  transactionLogContainer: {
    flex: 1,
    padding: 10,
  },
  noTransactionsText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#757575',
  },
  transactionHeader: {
    flexDirection: 'row',
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  transactionHeaderText: {
    fontWeight: 'bold',
    flex: 1,
    fontSize: 12,
  },
  transactionList: {
    flex: 1,
  },
  transactionItem: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  transactionDate: {
    flex: 1,
    fontSize: 12,
  },
  transactionType: {
    flex: 1,
    fontSize: 12,
  },
  transactionCategory: {
    flex: 1,
    fontSize: 12,
  },
  transactionAmount: {
    flex: 1,
    fontSize: 12,
  },
  salesText: {
    color: '#4CAF50',
  },
  expensesText: {
    color: '#F44336',
  },
  udhaarText: {
    color: '#2196F3',
  },
  summaryContainer: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 5,
    marginTop: 10,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  summaryLabel: {
    fontWeight: 'bold',
  },
  
  // Tab styles
  tabBar: {
    backgroundColor: '#fff',
  },
  tabIndicator: {
    backgroundColor: '#4CAF50',
  },
  tabLabel: {
    color: '#212121',
    fontWeight: 'bold',
  },
});

export default SahulatCalculator;